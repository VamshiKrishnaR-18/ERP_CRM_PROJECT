
  # ERP CRM Dashboard Design

  This is a code bundle for ERP CRM Dashboard Design. The original project is available at https://www.figma.com/design/KHkw8gxiNxWkHFz1sEqp5r/ERP-CRM-Dashboard-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  